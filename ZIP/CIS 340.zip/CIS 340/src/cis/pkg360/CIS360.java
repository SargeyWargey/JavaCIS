
package cis.pkg360;


public class CIS360 {


    public static void main(String[] args) {
        // "JAVA" PRINT LINE
    
    System.out.println("   J     A     V     V     A"   + "\n" 
                     + "   J    A A     V   V     A A"  + "\n"
                     + "J  J   AAAAA     V V     AAAAA" + "\n"
                     + " JJ   A     A     V     A     A");
  
    }
}
